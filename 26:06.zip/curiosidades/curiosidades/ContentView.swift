//
//  ContentView.swift
//  curiosidades
//
//  Created by Turma02-23 on 26/06/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                ZStack {
                    VStack {
                        HStack {
                            Text("Visite!")
                                .foregroundColor(.darkBlue)
                                .padding()
                                .font(.system(size: 27))
                                .bold()
                            
                            Image(systemName: "square.and.arrow.up")
                                .resizable()
                                .foregroundColor(.darkBlue)
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 27)
                            
                        }
                        .background(Rectangle()
                            .frame(width: 200, height: 70, alignment: .top)
                            .cornerRadius(20)
                            .foregroundColor(.blueish))
                        
                        Spacer(minLength: 30)
                        
                        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.")
                            .padding()
                            .foregroundColor(.darkBlue)
                        
                        Spacer(minLength: 30)
                        
                        HStack {
                            Text("Pontos turísticos:")
                            Spacer()
                        }
                        
                        ScrollView(.horizontal) {
                            HStack {
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.mediumBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.lightBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.lightBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.mediumBlue)
                                    .cornerRadius(10))
                            }
                        }
                        
                        Spacer(minLength: 50)
                        
                        HStack {
                            Text("Comidas típicas:")
                            Spacer()
                        }
                        
                        ScrollView(.horizontal) {
                            HStack {
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.lightBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.mediumBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.lightBlue)
                                    .cornerRadius(10))
                                
                                HStack {
                                    Text("Cidade linda do meu coracao")
                                        .foregroundColor(.blueish)
                                        .frame(width: 170, height: 150, alignment: .bottom)
                                        .padding(.bottom, 10)
                                }
                                .background(Rectangle()
                                    .frame(width: 170, height: 150)
                                    .foregroundColor(.mediumBlue)
                                    .cornerRadius(10))
                            }
                        }
                    }
                }
                .padding()
            }
        }
    }
}

#Preview {
    ContentView()
}

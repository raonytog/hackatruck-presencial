//
//  sheetPaisApp.swift
//  sheetPais
//
//  Created by Turma02-23 on 28/06/24.
//

import SwiftUI

@main
struct sheetPaisApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(descricao: "",
                        turismo: [Cultura(nome: "", imagem: "")],
                        comidas: [Cultura(nome: "", imagem: "")])
        }
    }
}

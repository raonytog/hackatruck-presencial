//
//  ContentView.swift
//  sheetPais
//
//  Created by Turma02-23 on 28/06/24.
//

import SwiftUI

struct ContentView: View {
    var nome: String = ""
    var descricao: String = ""
    var turismo: [Cultura]
    var comidas: [Cultura]
    
    var body: some View {
        NavigationStack {
            ScrollView (showsIndicators: false) {
                Spacer(minLength: 20)
                ZStack {
                    VStack {
                        NavigationLink(destination: EmptyView().navigationBarBackButtonHidden(true)) {
                            HStack {
                                Text("Visite! ")
                                    .foregroundColor(.darkBlue)
                                    .font(.system(size: 22))
                                    .bold()
                                
                                Image(systemName: "square.and.arrow.up")
                                    .resizable()
                                    .foregroundColor(.darkBlue)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 22)
                                    .padding(.bottom, 7)
                            }
                            .background(Rectangle()
                                .frame(width: 160, height:55, alignment: .top)
                                .cornerRadius(20)
                                .foregroundColor(.blueish))
                        }
                        .navigationBarBackButtonHidden(true)
                        
                        Spacer(minLength: 30)
                        
                        Text(descricao)
                            .padding()
                            .foregroundColor(.darkBlue)
                        
                        Spacer(minLength: 30)
                        
                        HStack {
                            Text("Pontos turísticos:")
                                .font(.system(size: 20))
                                .foregroundColor(.darkBlue)
                                .bold()
                            Spacer()
                        }
                        
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(turismo, id: \.self) { turi in
                                VStack {
                                        AsyncImage(url: URL(string: turi.imagem)) {
                                            img in img
                                                .resizable()
                                                .frame(width: 170, height: 96)
                                                .clipped()
                                                .background(Rectangle()
                                                    .frame(width: 170, height: 210)
                                                    .foregroundColor(.mediumBlue)
                                                    .cornerRadius(8))
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        
                                    Text(turi.nome)
                                            .foregroundColor(.white)
                                            .multilineTextAlignment(.center)
                                            .frame(width: 170, height: 70, alignment: .top)
                                    }
                                }
                            }
                        }
                        
                        HStack {
                            Text("Comidas tipicas:")
                                .font(.system(size: 20))
                                .foregroundColor(.darkBlue)
                                .bold()
                            Spacer()
                        }
                        
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(comidas, id: \.self) { food in
                                    VStack {
                                        AsyncImage(url: URL(string: food.imagem)) {
                                            img in img
                                                .resizable()
                                                .frame(width: 170, height: 96)
                                                .clipped()
                                                .background(Rectangle()
                                                    .frame(width: 170, height: 210)
                                                    .foregroundColor(.mediumBlue)
                                                    .cornerRadius(8))
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        
                                        Text(food.nome)
                                            .foregroundColor(.white)
                                            .multilineTextAlignment(.center)
                                            .frame(width: 170, height: 80, alignment: .top)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView(descricao: "Bem-vindo ao Brasil, um país de paisagens deslumbrantes e cultura vibrante. Com praias paradisíacas, florestas tropicais exuberantes e uma cena cultural rica, o Brasil encanta com sua música, dança e gastronomia únicas. Explore cidades cosmopolitas, como Rio de Janeiro e São Paulo, ou relaxe em destinos tropicais como Florianópolis. Descubra a hospitalidade calorosa e o encanto diversificado deste país incrível.",

                turismo: [
                    Cultura(nome: "Cristo Redentor", imagem: "https://www.nationalobserver.com/sites/nationalobserver.com/files/styles/nat_social/public/img/2021/12/16/ejprattlibraryuniversityoftoronto.jpg?itok=5nATr8gi"),
                    
                    Cultura(nome: "Foz do Iguaçu", imagem: "https://www.tcd.ie/Economics/assets/images/homepage/slider-research.jpg")],
                
                comidas: [
                    Cultura(nome: "Feijoada",imagem: "https://dynamic-media-cdn.tripadvisor.com/media/photo-s/02/33/9d/48/trinity-college-campus.jpg?w=500&h=-1&s=1"),
                            
                    Cultura(nome: "Caipirinha", imagem: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcStDRKCb7FupHaGMVjQjzLSOhez9TSiE7U_ocRT1eNqUtfs6m3QYMeQv61GCikaP9bZvQM&usqp=CAU")])
}

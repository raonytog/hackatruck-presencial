//
//  curiosidadesApp.swift
//  curiosidades
//
//  Created by Turma02-23 on 26/06/24.
//

import SwiftUI

@main
struct curiosidadesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
